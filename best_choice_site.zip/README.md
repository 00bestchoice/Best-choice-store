
# Best Choice Store

This is a bilingual (Arabic/English) minimalist e-commerce site with beige, brown, and light pink color tones.
Designed for a skincare brand called Best Choice.

### Pages:
- Home
- Shop
- Contact

### Languages:
- Arabic (default)
- English (`/en/` folder)

Designed for GitHub Pages deployment.
